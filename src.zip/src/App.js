import "./App.css";
import Sidebar from "./components/Sidebar";
import AddBar from "./components/AddBar";
import MovieSlider from "./components/MovieSlider";
import Opener from "./components/Opener";
function App() {
  return (
    <div className="App">
      <Opener />
      <Sidebar />
      <MovieSlider />
    </div>
  );
}

export default App;
