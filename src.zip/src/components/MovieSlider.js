import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { BsFillPlayFill } from "react-icons/bs";
import DoneIcon from "@mui/icons-material/Done";
function MovieSlider() {
  const MovieItems = [
    {
      index: 1,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/7475/1557475-i-e371b3e8fdb4",
      titleImage:
        "https://img10.hotstar.com/image/upload/f_auto,h_148/sources/r1/cms/prod/7474/1557474-t-c7f82f7f99df",
      year: 2022,
      duration: "2h 29m",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      restrictions: "U/A 16+",
      description:
        "The band of heroic renegates embark on the action-packed mission to protect one of their own. And a new force threatens to bring the Guardian down for good.",
      newlyAdded: true,
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 2,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/5290/1405290-i-57a1df9bf3e7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 3,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 4,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 5,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 6,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 7,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 8,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
    {
      index: 9,
      link: "https://img10.hotstar.com/image/upload/f_auto,q_90,w_1920/sources/r1/cms/prod/6554/1566554-i-7b8ecb1234b7",
      language: ["Hindi", "English", "Tamil", "Telgu", "Malyalam"],
      tags: ["SuperHero", "Action", "Adventure", "Comedy"],
    },
  ];

  const movieCount = MovieItems.length;
  const intervalDelay = 4000;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [wishlist, setWishlist] = useState(false);

  const handleWishlist = () => {
    setWishlist(!wishlist);
  };
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % movieCount);
    }, intervalDelay);
    return () => clearInterval(interval);
  }, [movieCount]);
  const IndexZero = () => {
    setCurrentIndex(0);
  };
  const movieChoose = (index) => {
    setCurrentIndex(index - 1);
  };
  return (
    <>
      <Container>
        <Slider count={movieCount} index={currentIndex}>
          {MovieItems.map((item) => (
            <Set count={movieCount}>
              <Gradient></Gradient>
              <img
                key={item.index}
                src={item.link}
                alt={`Movie ${item.index}`}
              />
              <MovieDesc>
                <Compartment1>
                  <Detail className="jj">
                    <TitleImage>
                      <img
                        key={item.index}
                        src={item.titleImage}
                        alt="movieImage"
                      />
                    </TitleImage>
                    <Remain>
                      <Pointers>
                        <Year>{item.year}</Year>
                        <Duration>{item.duration}</Duration>
                        <Language>{item.language.length} Languages</Language>
                        <Restriction>{item.restrictions}</Restriction>
                      </Pointers>
                      <Descript>{item.description}</Descript>
                      <Tags>
                        {item.tags.map((ele) => {
                          return `${ele} | `;
                        })}
                      </Tags>
                      <ButtonSet>
                        <Button>
                          <BsFillPlayFill />
                          Watch Now
                        </Button>
                        <Wishlist onClick={handleWishlist}>
                          {wishlist ? <DoneIcon /> : "+"}
                        </Wishlist>
                      </ButtonSet>
                    </Remain>
                  </Detail>
                </Compartment1>
                <Compartment2></Compartment2>
              </MovieDesc>
            </Set>
          ))}
        </Slider>
        <SliderCover>
          <LeftArrow onClick={IndexZero} index={currentIndex}>
            &lt;
          </LeftArrow>
          <SmallSlider count={movieCount} index={currentIndex}>
            {MovieItems.map((ele) => (
              <MovieEle
                onClick={() => {
                  movieChoose(ele.index);
                }}
              >
                <img src={ele.link} alt="smallMovieImage" />
              </MovieEle>
            ))}

            {MovieItems.map((ele) => (
              <MovieEle
                onClick={() => {
                  movieChoose(ele.index);
                }}
              >
                <img src={ele.link} alt="smallMovieImage" />
              </MovieEle>
            ))}
          </SmallSlider>
        </SliderCover>
      </Container>
    </>
  );
}

export default MovieSlider;
const Container = styled.div`
  height: 95vh;
  width: 98vw;
  top: 52vh;
  position: absolute;
  z-index: -2;
  overflow: hidden;
  font-family: "Inter", sans-serif;
`;
const Gradient = styled.div`
  height: 95vh;
  width: 98vw;
  position: absolute;
  left: 0px;
  top: 20px;
  background-image: linear-gradient(
    to right,
    rgba(10, 11, 15, 1),
    rgba(10, 11, 15, 0),
    rgba(10, 11, 15, 0)
  );
  z-index: 100;
`;
const Slider = styled.div`
  height: 100%;
  width: ${(props) => {
    return props.count * 100;
  }}vw;
  z-index: -2;
  display: flex;
  flex-direction: row;
  transition: 2000ms;
  transform: translateX(-${(props) => (100 / props.count) * props.index}%);
  z-index: -2;
`;
const MovieDesc = styled.div`
  position: absolute;
  top: 100px;
  height: 500px;
  width: 88vw;
  left: 20px;
  z-index: 200;
  display: flex;
  justify-content: space-between;
`;
const Set = styled.div`
  width: ${(props) => {
    return 100 / props.count;
  }}%;
  height: 100%;
  img {
    height: 100%;
    width: 100%;
  }
  position: relative;
  left: 0;
`;
const Compartment1 = styled.div`
  margin-left: 80px;
  width: 25%;
  height: 100%;
`;
const Pointers = styled.div`
  display: flex;
  font-weight: 800;
  justify-content: space-around;
  margin-top: 30px;
  font-size: 15px;
`;
const Year = styled.div``;
const Duration = styled.div``;
const Language = styled.div``;
const Restriction = styled.div`
  background-color: rgba(350, 350, 350, 0.5);
  padding: 3px 5px;
  border: solid 2px rgb(365, 365, 365);
  border-radius: 5px;
`;
const Detail = styled.div`
  display: flex;
  flex-direction: column;
  height: 80%;
  color: white;
  margin-top: 0px;
`;
const TitleImage = styled.div`
  height: 150px;
  width: 300px;
  img {
    height: 100%;
    width: 100%;
  }
`;
const Remain = styled.div``;
const Descript = styled.div`
  margin-top: 10px;
  font-size: 15px;
  line-height: 22px;
`;
const Tags = styled.div`
  font-weight: 800;
  margin-top: 20px;
  margin-left: 10px;
`;
const Button = styled.div`
  width: 150px;
  padding: 15px 70px;
  border-radius: 10px;
  background-color: rgba(350, 350, 350, 0.3);
  margin-left: 10px;
  display: flex;
  cursor: pointer;
  &:hover {
    outline: 3px solid white;
  }

  justify-content: space-around;
`;
const ButtonSet = styled.div`
  display: flex;
  margin-top: 40px;
`;

const Wishlist = styled.div`
  width: 50px;
  height: 30px;
  padding: 10px 10px;
  font-size: 42px;
  border-radius: 10px;
  background-color: rgba(350, 350, 350, 0.3);
  margin-left: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  &:hover {
    outline: 3px solid white;
  }

  justify-content: space-around;
`;

const Compartment2 = styled.div`
  width: 40%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
`;
const SliderCover = styled.div`
  position: absolute;
  top: 480px;
  left: 800px;
  width: 36%;
  height: 60px;
  margin-bottom: 60px;
  overflow: hidden;
  z-index: 100;
`;
const LeftArrow = styled.div`
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 40px;
  height: 100%;
  background-image: linear-gradient(
    to right,
    rgba(10, 11, 15, 0.7),
    rgba(10, 11, 15, 0)
  );
  z-index: 100;
  color: white;
  cursor: pointer;
  display: ${(props) => {
    if (props.index === 0) return "none";
    else return "flex";
  }};
  justify-content: center;
  align-items: center;
  font-size: 30px;
`;
const SmallSlider = styled.div`
  width: 100%;
  height: 100%;
  display: grid;
  grid-gap: 10px;
  grid-template-columns: repeat(${(props) => props.count * 2}, 85px);
  transition: 2000ms;
  transform: translateX(-${(props) => (157 / props.count) * props.index}%);
  align-items: center;
  z-index: -1;
`;
const MovieEle = styled.div`
  height: 80%;
  position: relative;
  width: 85px;
  margin-left: 5px;
  top: -20px;
  img {
    height: 80%;
    width: 95%;
    border-radius: 5px;
    opacity: 80%;
  }
  z-index: -1;
  transition: 500ms;
  cursor: pointer;
  &:hover {
    transform: scale(1.2);
  }
`;
