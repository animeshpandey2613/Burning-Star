import React, { useState } from "react";
import "./Sidebar.css";
import Styled from "styled-components";
import { AiOutlineHome, AiFillHome } from "react-icons/ai";
import LogoImg from "../logo-d-plus.png";
import {
  BiSearch,
  BiTv,
  BiSolidTv,
  BiCameraMovie,
  BiSolidCameraMovie,
  BiCricketBall,
  BiSolidCricketBall,
} from "react-icons/bi";

function Sidebar() {
  const [menuOpener, setMenuOpener] = useState(false);
  const [menuItems, setMenuItems] = useState({
    Home: false,
    Search: false,
    TV: false,
    Movie: false,
    Sports: false,
  });

  //LEARN THIS TOGGLE CODE!!!!!!
  const toggleMenuItem = (item) => {
    setMenuItems((prevMenuItems) => ({
      ...prevMenuItems,
      [item]: !prevMenuItems[item],
    }));
  };

  const menuMouseOpener = () => {
    setMenuOpener(true);
  };

  const menuMouseCloser = () => {
    setMenuOpener(false);
  };

  const menuItemsArray = [
    { name: "Home", icon: menuItems.Home ? <AiFillHome /> : <AiOutlineHome /> },
    { name: "Search", icon: <BiSearch /> },
    { name: "TV", icon: menuItems.TV ? <BiSolidTv /> : <BiTv /> },
    {
      name: "Movie",
      icon: menuItems.Movie ? <BiSolidCameraMovie /> : <BiCameraMovie />,
    },
    {
      name: "Sports",
      icon: menuItems.Sports ? <BiSolidCricketBall /> : <BiCricketBall />,
    },
  ];

  return (
    <div className="container" onMouseEnter={menuMouseOpener}>
      <div className="menu">
        <div className="Group">
          {menuItemsArray.map((item, index) => (
            <div key={index} className="icon">
              {menuOpener ? "" : item.icon}
            </div>
          ))}
        </div>
      </div>
      <Slider temp={menuOpener} onMouseLeave={menuMouseCloser}>
        <div className="Group">
          {menuItemsArray.map((item, index) => (
            <Pair
              key={index}
              onMouseEnter={() => toggleMenuItem(item.name)}
              onMouseLeave={() => toggleMenuItem(item.name)}
            >
              <IconContainer temp={menuItems[item.name]}>
                {item.icon}
              </IconContainer>
              <Text temp={menuItems[item.name]}>{item.name}</Text>
            </Pair>
          ))}
        </div>
      </Slider>
      <img src={LogoImg} />
    </div>
  );
}

export default Sidebar;

const Slider = Styled.div`
font-family: "Inter", sans-serif;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  width: 25vw;
  display:flex;
  justify-content:center;
  transform: ${(props) =>
    props.temp ? "translateX(0%)" : "translateX(-100%)"};
  transition: transform 0.5s ease-in-out;
  background-image: linear-gradient(to right, rgba(0,0,0,1), rgba(255,0,0,0));
`;

const IconContainer = Styled.div`
  position: absolute;
  filter: invert(1);
  left: 32px;
  transition:300ms;
  top: 15px;
  transform: ${(props) =>
    props.temp ? "scale(1.5) translateX(7%)" : "scale(1) translateX(0%)"};
`;

const Pair = Styled.div`
  display: flex;
  width: 25vw;
  height: 50px;
  .text{
    font-size:16px;
  }
  position: relative;
  cursor:pointer;
`;
const Text = Styled.div`
position: absolute;
left: 70px;
top: 15px;
color:white;
transition:300ms;
transform: ${(props) =>
  props.temp ? "scale(1.5) translateX(50%)" : "scale(1) translateX(0%)"};`;
